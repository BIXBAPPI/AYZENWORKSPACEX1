# ID: AX01      |  Local: A0Y1          |  Module: X01 (M00)
# Functions: A0Y1F1 A0Y1F2 A0Y1F3
# Processes: XN01 XN02 XN03
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from dotenv import load_dotenv
load_dotenv()

import redis.asyncio as aioredis
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

logger = logging.getLogger("ayzen")

# ── Globals ──────────────────────────────────────────────────────────────────
engine = None
session_factory: async_sessionmaker | None = None
redis_client = None
scheduler: AsyncIOScheduler | None = None

# ── XN02  Lifespan — Startup & Shutdown ──────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    global engine, session_factory, redis_client, scheduler

    # Database — normalize URL to asyncpg dialect
    raw_url = os.environ.get("DATABASE_URL", "")
    if not raw_url:
        raise RuntimeError("DATABASE_URL environment variable is required")

    # Replace scheme to use asyncpg driver
    database_url = raw_url
    if database_url.startswith("postgres://"):
        database_url = "postgresql+asyncpg://" + database_url[len("postgres://"):]
    elif database_url.startswith("postgresql://") and "+asyncpg" not in database_url:
        database_url = "postgresql+asyncpg://" + database_url[len("postgresql://"):]

    # asyncpg does not support sslmode= query param — strip it and pass connect_args
    from urllib.parse import urlparse, urlencode, parse_qs, urlunparse
    parsed = urlparse(database_url)
    qs = parse_qs(parsed.query, keep_blank_values=True)
    sslmode = qs.pop("sslmode", ["require"])[0]
    new_query = urlencode({k: v[0] for k, v in qs.items()})
    database_url = urlunparse(parsed._replace(query=new_query))

    connect_args: dict = {}
    if sslmode in ("disable", "allow", "prefer"):
        connect_args["ssl"] = False
    elif sslmode in ("require", "verify-ca", "verify-full"):
        connect_args["ssl"] = True

    engine = create_async_engine(
        database_url,
        pool_size=10,
        max_overflow=20,
        echo=False,
        connect_args=connect_args,
    )
    session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    app.state.db = session_factory

    # Redis
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
    try:
        redis_client = aioredis.from_url(redis_url, decode_responses=True)
        await redis_client.ping()
        app.state.redis = redis_client
        logger.info("Redis connected")
    except Exception as exc:
        logger.warning("Redis unavailable — stateless mode active: %s", exc)
        app.state.redis = None

    # APScheduler
    scheduler = AsyncIOScheduler()
    _register_jobs(scheduler)
    scheduler.start()
    logger.info("Scheduler started")

    # Telegram webhook auto-registration
    await _register_telegram_webhook()

    yield

    # Shutdown
    scheduler.shutdown(wait=False)
    if redis_client:
        await redis_client.aclose()
    if engine:
        await engine.dispose()
    logger.info("AYZEN shutdown complete")


async def _register_telegram_webhook() -> None:
    """Call Telegram setWebhook at startup if WEBHOOK_BASE_URL is configured."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    base_url = os.environ.get("WEBHOOK_BASE_URL", "").rstrip("/")
    if not token or not base_url:
        if not token:
            logger.warning("TELEGRAM_BOT_TOKEN not set — skipping webhook registration")
        if not base_url:
            logger.info("WEBHOOK_BASE_URL not set — skipping webhook registration (set it to your public domain, e.g. https://ayzen.tech)")
        return

    webhook_url = f"{base_url}/api/v1/bot/webhook"
    secret_token = os.environ.get("INTERNAL_WEBHOOK_TOKEN", "")

    payload: dict = {"url": webhook_url, "allowed_updates": ["message", "callback_query", "inline_query"]}
    if secret_token:
        payload["secret_token"] = secret_token

    try:
        import httpx
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"https://api.telegram.org/bot{token}/setWebhook",
                json=payload,
            )
            data = resp.json()
            if data.get("ok"):
                logger.info("Telegram webhook registered: %s", webhook_url)
            else:
                logger.error("Telegram setWebhook failed: %s", data)
    except Exception as exc:
        logger.warning("Could not register Telegram webhook: %s", exc)


def _register_jobs(scheduler: AsyncIOScheduler) -> None:
    from apps.api.app.jobs.deadline_reminder import run as deadline_run
    from apps.api.app.jobs.daily_digest import run as digest_run
    from apps.api.app.jobs.analytics_job import run as analytics_run
    from apps.api.app.jobs.stale_user_job import run as stale_run
    from apps.api.app.jobs.quiet_queue_job import run as quiet_run

    scheduler.add_job(deadline_run, "interval", minutes=15, id="deadline_reminder")
    scheduler.add_job(digest_run, "cron", hour=8, minute=0, id="daily_digest")
    scheduler.add_job(analytics_run, "cron", hour=2, minute=0, id="analytics_snapshot")
    scheduler.add_job(stale_run, "cron", hour=3, minute=0, id="stale_user")
    scheduler.add_job(quiet_run, "interval", minutes=5, id="quiet_queue_flush")


# ── XN01  App Factory ─────────────────────────────────────────────────────────
def create_app() -> FastAPI:
    # CORS origins — parsed from env; also auto-include Replit deployment domains
    cors_origins_raw = os.environ.get("CORS_ORIGINS", "")
    cors_origins = [o.strip() for o in cors_origins_raw.split(",") if o.strip()]

    # Auto-add REPLIT_DOMAINS (comma-separated list of live deployment domains)
    replit_domains_raw = os.environ.get("REPLIT_DOMAINS", "")
    for domain in replit_domains_raw.split(","):
        domain = domain.strip()
        if domain:
            for scheme in ("https://", "http://"):
                origin = f"{scheme}{domain}"
                if origin not in cors_origins:
                    cors_origins.append(origin)

    # Auto-add REPLIT_DEV_DOMAIN for local dev preview
    dev_domain = os.environ.get("REPLIT_DEV_DOMAIN", "").strip()
    if dev_domain:
        for scheme in ("https://", "http://"):
            origin = f"{scheme}{dev_domain}"
            if origin not in cors_origins:
                cors_origins.append(origin)

    if not cors_origins:
        logger.warning("CORS_ORIGINS not set and no REPLIT_DOMAINS found — CORS will block all requests")

    # In production (behind Replit proxy / custom domain) the Host header is the
    # public domain. We default to "*" and let CORS + Telegram token do the actual
    # security — TrustedHostMiddleware strict mode would break custom domains.
    raw_allowed = os.environ.get("ALLOWED_HOSTS", "*")
    allowed_hosts = ["*"] if raw_allowed == "*" else [h.strip() for h in raw_allowed.split(",") if h.strip()]

    app = FastAPI(
        title="AYZEN API",
        version="5.0.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        lifespan=lifespan,
    )

    # Middleware
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-CSRF-Token"],
    )

    # Exception handlers
    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("Unhandled error on %s", request.url)
        return JSONResponse(status_code=500, content={"detail": "internal_error"})

    # Routers
    from apps.api.app.integrations.telegram.webhook import router as telegram_router
    from apps.api.app.routers.auth import router as auth_router
    from apps.api.app.routers.projects import router as projects_router
    from apps.api.app.routers.tasks import router as tasks_router
    from apps.api.app.routers.members import router as members_router
    from apps.api.app.routers.progress import router as progress_router
    from apps.api.app.routers.analytics import router as analytics_router
    from apps.api.app.routers.broadcasts import router as broadcasts_router
    from apps.api.app.routers.exports import router as exports_router
    from apps.api.app.routers.settings import router as settings_router
    from apps.api.app.routers.notifications import router as notifications_router
    from apps.api.app.routers.tma_auth import router as tma_router

    app.include_router(telegram_router, prefix="/api/v1")
    app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(projects_router, prefix="/api/v1/projects", tags=["projects"])
    app.include_router(tasks_router, prefix="/api/v1/tasks", tags=["tasks"])
    app.include_router(members_router, prefix="/api/v1/members", tags=["members"])
    app.include_router(progress_router, prefix="/api/v1/progress", tags=["progress"])
    app.include_router(analytics_router, prefix="/api/v1/analytics", tags=["analytics"])
    app.include_router(broadcasts_router, prefix="/api/v1/broadcasts", tags=["broadcasts"])
    app.include_router(exports_router, prefix="/api/v1/exports", tags=["exports"])
    app.include_router(settings_router, prefix="/api/v1/settings", tags=["settings"])
    app.include_router(notifications_router, prefix="/api/v1/notifications", tags=["notifications"])
    app.include_router(tma_router, prefix="/api/v1/tma", tags=["tma"])

    # XN03  Health endpoint — no auth, used by load balancer
    @app.get("/api/v1/health", tags=["health"])
    async def health_check() -> dict:
        return {"status": "ok", "version": "5.0.0"}

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
