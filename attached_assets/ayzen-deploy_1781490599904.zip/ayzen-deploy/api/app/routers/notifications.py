# ID: AX87      |  Local: A64Y1         |  Module: X68 (M67)
# Functions: A64Y1F1 A64Y1F2 A64Y1F3
# Processes: XN01 XN02 XN03
from __future__ import annotations

import logging
from sqlalchemy import text
from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel

logger = logging.getLogger("ayzen.routers.notifications")

router = APIRouter()


class SendNotificationRequest(BaseModel):
    user_id: UUID
    message_key: str
    locale: str = "bn"
    params: dict = {}


async def _auth_admin(request: Request):
    from apps.api.app.middleware.auth import verify_token, require_admin
    user = await verify_token(request)
    await require_admin(user)
    return user


@router.post("/send")
async def send_notification(body: SendNotificationRequest, request: Request) -> dict:
    """A64Y1F1: Send notification to specific user (admin only)."""
    user = await _auth_admin(request)
    db = request.app.state.db
    redis = request.app.state.redis

    from apps.api.app.integrations.telegram.client import get_telegram_client
    from apps.api.app.services.notification_service import NotificationService

    client = get_telegram_client()
    notif_svc = NotificationService(redis, db, client)

    async with db() as session:
        result = await session.execute(
            text("SELECT telegram_user_id FROM users WHERE id = :uid"),
            {"uid": str(body.user_id)},
        )
        row = result.fetchone()
        if not row or not row.telegram_user_id:
            return {"status": "no_telegram_linked"}

    await notif_svc.send_or_queue(
        telegram_user_id=row.telegram_user_id,
        message_key=body.message_key,
        locale=body.locale,
        **body.params,
    )
    return {"status": "sent"}


@router.post("/flush/{user_id}")
async def flush_queue(user_id: UUID, request: Request) -> dict:
    """A64Y1F2: Flush queued notifications for user."""
    user = await _auth_admin(request)
    db = request.app.state.db
    redis = request.app.state.redis

    async with db() as session:
        result = await session.execute(
            text("SELECT telegram_user_id FROM users WHERE id = :uid"),
            {"uid": str(user_id)},
        )
        row = result.fetchone()
        if not row or not row.telegram_user_id:
            return {"status": "no_telegram", "flushed": 0}

    from apps.api.app.integrations.telegram.client import get_telegram_client
    from apps.api.app.services.notification_service import NotificationService
    svc = NotificationService(redis, db, get_telegram_client())
    count = await svc.flush_queue(row.telegram_user_id)
    return {"status": "flushed", "count": count}


@router.get("/settings")
async def get_notification_settings(request: Request) -> dict:
    """A64Y1F3: Get current user's notification settings."""
    from apps.api.app.middleware.auth import verify_token
    user = await verify_token(request)
    db = request.app.state.db
    redis = request.app.state.redis

    from apps.api.app.services.user_settings_service import UserSettingsService
    svc = UserSettingsService(redis, db)

    # Get by user_id (we need telegram_user_id for the cache, so use DB directly)
    async with db() as session:
        result = await session.execute(
            text("""
            SELECT notify_deadline, notify_assignment, notify_broadcast,
                   quiet_hours_start, quiet_hours_end
            FROM user_settings WHERE user_id = :uid
            """),
            {"uid": str(user.user_id)},
        )
        row = result.fetchone()
        if not row:
            return {"notify_deadline": True, "notify_assignment": True, "notify_broadcast": True}
        return dict(row._mapping)
