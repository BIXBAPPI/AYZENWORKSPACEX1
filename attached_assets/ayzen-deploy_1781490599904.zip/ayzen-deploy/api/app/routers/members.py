# ID: AX77      |  Local: A54Y1         |  Module: X58 (M57)
# Functions: A54Y1F1 A54Y1F2 A54Y1F3 A54Y1F4
# Processes: XN01 XN02 XN03 XN04
from __future__ import annotations

import logging
from sqlalchemy import text
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, EmailStr

logger = logging.getLogger("ayzen.routers.members")

router = APIRouter()


class InviteMemberRequest(BaseModel):
    project_id: UUID
    email: EmailStr
    role: str = "member"


class UpdateMemberRequest(BaseModel):
    role: str


async def _auth(request: Request):
    from apps.api.app.middleware.auth import verify_token
    return await verify_token(request)


@router.get("/{project_id}")
async def list_members(project_id: UUID, request: Request) -> list[dict]:
    """A54Y1F1: List project members."""
    user = await _auth(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT u.id, u.email, u.full_name, u.telegram_user_id, pm.role, pm.assigned_at,
                   COUNT(tc.id) as completion_count
            FROM project_members pm
            JOIN users u ON u.id = pm.user_id
            LEFT JOIN task_completions tc ON tc.user_id = u.id
            WHERE pm.project_id = :pid
            GROUP BY u.id, u.email, u.full_name, u.telegram_user_id, pm.role, pm.assigned_at
            ORDER BY completion_count DESC
            """),
            {"pid": str(project_id)},
        )
        return [dict(r._mapping) for r in result.fetchall()]


@router.post("/invite", status_code=201)
async def invite_member(body: InviteMemberRequest, request: Request) -> dict:
    """A54Y1F2: Invite user to project by email."""
    user = await _auth(request)
    from apps.api.app.middleware.auth import require_admin
    await require_admin(user)

    db = request.app.state.db
    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))

        # Find user by email
        result = await session.execute(
            text("SELECT id FROM users WHERE email = :email AND tenant_id = :tid"),
            {"email": body.email, "tid": str(user.tenant_id)},
        )
        row = result.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="user_not_found")

        invited_user_id = row.id

        # Add to project
        await session.execute(
            text("""
            INSERT INTO project_members (project_id, user_id, role, assigned_by)
            VALUES (:pid, :uid, :role, :assigned_by)
            ON CONFLICT (project_id, user_id) DO UPDATE SET role = EXCLUDED.role
            """),
            {
                "pid": str(body.project_id), "uid": str(invited_user_id),
                "role": body.role, "assigned_by": str(user.user_id),
            },
        )
        await session.commit()

        # Send Telegram notification if linked
        tg_result = await session.execute(
            text("SELECT telegram_user_id FROM users WHERE id = :uid"),
            {"uid": str(invited_user_id)},
        )
        tg_row = tg_result.fetchone()
        if tg_row and tg_row.telegram_user_id:
            try:
                from apps.api.app.integrations.telegram.client import get_telegram_client
                from apps.api.app.services.i18n_service import t
                from apps.api.app.services.user_settings_service import UserSettingsService
                settings_svc = UserSettingsService(request.app.state.redis, db)
                locale = await settings_svc.get_locale(tg_row.telegram_user_id)
                client = get_telegram_client()
                await client.send_message(
                    tg_row.telegram_user_id,
                    t("notification.assignment", locale,
                      task_title="Project Access",
                      project_name=str(body.project_id),
                      deadline="—"),
                )
            except Exception:
                pass

    return {"status": "invited", "email": body.email, "role": body.role}


@router.patch("/{project_id}/{user_id}")
async def update_member_role(project_id: UUID, user_id: UUID, body: UpdateMemberRequest, request: Request) -> dict:
    """A54Y1F3: Update member role."""
    user = await _auth(request)
    from apps.api.app.middleware.auth import require_admin
    await require_admin(user)

    db = request.app.state.db
    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        await session.execute(
            text("UPDATE project_members SET role = :role WHERE project_id = :pid AND user_id = :uid"),
            {"role": body.role, "pid": str(project_id), "uid": str(user_id)},
        )
        await session.commit()
    return {"status": "updated", "role": body.role}


@router.delete("/{project_id}/{user_id}", status_code=204)
async def remove_member(project_id: UUID, user_id: UUID, request: Request) -> None:
    """A54Y1F4: Remove member from project."""
    user = await _auth(request)
    from apps.api.app.middleware.auth import require_admin
    await require_admin(user)

    db = request.app.state.db
    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        await session.execute(
            text("DELETE FROM project_members WHERE project_id = :pid AND user_id = :uid"),
            {"pid": str(project_id), "uid": str(user_id)},
        )
        await session.commit()
