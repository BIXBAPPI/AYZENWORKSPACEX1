# ID: AX83      |  Local: A60Y1         |  Module: X64 (M63)
# Functions: A60Y1F1 A60Y1F2 A60Y1F3
# Processes: XN01 XN02 XN03
from __future__ import annotations

import logging
from sqlalchemy import text

from fastapi import APIRouter, Request
from pydantic import BaseModel

logger = logging.getLogger("ayzen.routers.settings")

router = APIRouter()


class UpdateSettingsRequest(BaseModel):
    locale: str | None = None
    notify_deadline: bool | None = None
    notify_assignment: bool | None = None
    notify_broadcast: bool | None = None
    quiet_hours_start: str | None = None  # "HH:MM"
    quiet_hours_end: str | None = None    # "HH:MM"


async def _auth(request: Request):
    from apps.api.app.middleware.auth import verify_token
    return await verify_token(request)


@router.get("/")
async def get_settings(request: Request) -> dict:
    """A60Y1F1: Get user settings."""
    user = await _auth(request)
    db = request.app.state.db

    async with db() as session:
        result = await session.execute(
            text("""
            SELECT locale, notify_deadline, notify_assignment, notify_broadcast,
                   quiet_hours_start, quiet_hours_end, updated_at
            FROM user_settings
            WHERE user_id = :uid
            """),
            {"uid": str(user.user_id)},
        )
        row = result.fetchone()
        if not row:
            return {
                "locale": "bn", "notify_deadline": True, "notify_assignment": True,
                "notify_broadcast": True, "quiet_hours_start": None, "quiet_hours_end": None,
            }
        return dict(row._mapping)


@router.patch("/")
async def update_settings(body: UpdateSettingsRequest, request: Request) -> dict:
    """A60Y1F2: Update user settings."""
    user = await _auth(request)
    db = request.app.state.db
    redis = request.app.state.redis

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        return {"status": "no_changes"}

    async with db() as session:
        set_clauses = ", ".join(f"{k} = :{k}" for k in updates)
        updates["uid"] = str(user.user_id)
        await session.execute(
            text(f"""
            INSERT INTO user_settings (user_id) VALUES (:uid)
            ON CONFLICT (user_id) DO NOTHING
            """),
            {"uid": str(user.user_id)},
        )
        await session.execute(
            text(f"UPDATE user_settings SET {set_clauses}, updated_at = NOW() WHERE user_id = :uid"),
            updates,
        )
        if "locale" in updates:
            await session.execute(
                text("UPDATE user_bot_state SET locale = :locale WHERE user_id = :uid"),
                {"locale": updates["locale"], "uid": str(user.user_id)},
            )
        await session.commit()

    # Invalidate Redis cache
    if redis:
        try:
            await redis.delete(f"ayzen:settings:tg:*")
        except Exception:
            pass

    return {"status": "updated"}


@router.delete("/bot-link")
async def unlink_bot(request: Request) -> dict:
    """A60Y1F3: Unlink Telegram bot account."""
    user = await _auth(request)
    db = request.app.state.db
    redis = request.app.state.redis

    from apps.api.app.services.bot_user_service import BotUserService
    svc = BotUserService(redis, db)
    await svc.unlink(user.user_id)

    return {"status": "unlinked"}
