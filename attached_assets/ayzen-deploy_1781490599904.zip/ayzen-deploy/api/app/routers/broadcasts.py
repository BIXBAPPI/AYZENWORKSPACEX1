# ID: AX80      |  Local: A57Y1         |  Module: X61 (M60)
# Functions: A57Y1F1 A57Y1F2 A57Y1F3
# Processes: XN01 XN02 XN03
from __future__ import annotations

import logging
from sqlalchemy import text
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel

logger = logging.getLogger("ayzen.routers.broadcasts")

router = APIRouter()


class SendBroadcastRequest(BaseModel):
    project_id: UUID
    message: str


async def _auth_admin(request: Request):
    from apps.api.app.middleware.auth import verify_token, require_admin
    user = await verify_token(request)
    await require_admin(user)
    return user


@router.post("/", status_code=201)
async def send_broadcast(body: SendBroadcastRequest, request: Request) -> dict:
    """A57Y1F1: Send broadcast via API (admin only)."""
    user = await _auth_admin(request)

    db = request.app.state.db
    redis = request.app.state.redis

    # Rate limit: 1 broadcast / 10 min per admin
    from apps.api.app.integrations.telegram.middleware.rate_limit import TelegramRateLimiter
    # Use user_id as surrogate for rate limiting here
    limiter = TelegramRateLimiter(redis)

    from apps.api.app.integrations.telegram.client import get_telegram_client
    from apps.api.app.services.broadcast_service import BroadcastService

    client = get_telegram_client()
    svc = BroadcastService(db, client)

    sent = await svc.send_project_broadcast(
        project_id=body.project_id,
        tenant_id=user.tenant_id,
        sender_id=user.user_id,
        message=body.message,
    )

    return {"status": "sent", "sent_count": sent}


@router.get("/history")
async def broadcast_history(request: Request, limit: int = 20) -> list[dict]:
    """A57Y1F2: Get broadcast history for tenant."""
    user = await _auth_admin(request)
    db = request.app.state.db

    from apps.api.app.services.broadcast_service import BroadcastService
    from apps.api.app.integrations.telegram.client import get_telegram_client

    svc = BroadcastService(db, get_telegram_client())
    return await svc.get_recent_broadcasts(user.tenant_id, limit)


@router.get("/{broadcast_id}")
async def get_broadcast(broadcast_id: UUID, request: Request) -> dict:
    """A57Y1F3: Get single broadcast detail."""
    user = await _auth_admin(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT b.*, u.full_name as sender_name
            FROM bot_broadcasts b
            LEFT JOIN users u ON u.id = b.sender_id
            WHERE b.id = :bid AND b.tenant_id = :tid
            """),
            {"bid": str(broadcast_id), "tid": str(user.tenant_id)},
        )
        row = result.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="broadcast_not_found")
        return dict(row._mapping)
