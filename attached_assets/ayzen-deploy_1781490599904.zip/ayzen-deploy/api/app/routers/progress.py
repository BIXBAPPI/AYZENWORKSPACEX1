# ID: AX78      |  Local: A55Y1         |  Module: X59 (M58)
# Functions: A55Y1F1 A55Y1F2 A55Y1F3
# Processes: XN01 XN02 XN03
from __future__ import annotations

import logging
from sqlalchemy import text
from datetime import date
from uuid import UUID

from fastapi import APIRouter, Request

logger = logging.getLogger("ayzen.routers.progress")

router = APIRouter()


async def _auth(request: Request):
    from apps.api.app.middleware.auth import verify_token
    return await verify_token(request)


@router.get("/me")
async def my_progress(request: Request, project_id: UUID | None = None) -> dict:
    """A55Y1F1: Get current user's progress summary."""
    user = await _auth(request)
    db = request.app.state.db
    today = date.today()

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))

        where = "AND t.project_id = :pid" if project_id else ""
        params: dict = {"uid": str(user.user_id)}
        if project_id:
            params["pid"] = str(project_id)

        result = await session.execute(
            text(f"""
            SELECT
                COUNT(DISTINCT tc.id) as total_completions,
                COALESCE(SUM(tc.points_earned), 0) as total_points,
                COUNT(DISTINCT tc.id) FILTER (WHERE DATE(tc.completed_at) = :today) as today_completions,
                COALESCE(SUM(tc.points_earned) FILTER (WHERE DATE(tc.completed_at) = :today), 0) as today_points,
                COUNT(DISTINCT t.id) as total_tasks
            FROM tasks t
            JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = :uid
            LEFT JOIN task_completions tc ON tc.task_id = t.id AND tc.user_id = :uid
            WHERE t.archived_at IS NULL {where}
            """),
            {**params, "today": today},
        )
        row = result.fetchone()

    return {
        "total_completions": row.total_completions if row else 0,
        "total_points": int(row.total_points) if row else 0,
        "today_completions": row.today_completions if row else 0,
        "today_points": int(row.today_points) if row else 0,
        "total_tasks": row.total_tasks if row else 0,
        "completion_rate": round((row.total_completions / max(row.total_tasks, 1)) * 100, 1) if row else 0,
    }


@router.get("/leaderboard/{project_id}")
async def leaderboard(project_id: UUID, request: Request, limit: int = 20) -> list[dict]:
    """A55Y1F2: Get project leaderboard."""
    user = await _auth(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT u.full_name, u.email,
                   COUNT(tc.id) as completions,
                   COALESCE(SUM(tc.points_earned), 0) as total_points,
                   RANK() OVER (ORDER BY SUM(tc.points_earned) DESC) as rank
            FROM project_members pm
            JOIN users u ON u.id = pm.user_id
            LEFT JOIN task_completions tc ON tc.user_id = u.id
            JOIN tasks t ON t.id = tc.task_id AND t.project_id = :pid
            WHERE pm.project_id = :pid
            GROUP BY u.full_name, u.email
            ORDER BY total_points DESC
            LIMIT :limit
            """),
            {"pid": str(project_id), "limit": limit},
        )
        return [dict(r._mapping) for r in result.fetchall()]


@router.get("/history/{project_id}")
async def completion_history(project_id: UUID, request: Request, days: int = 30) -> list[dict]:
    """A55Y1F3: Daily completion history for charts."""
    user = await _auth(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT
                DATE(tc.completed_at) as completion_date,
                COUNT(tc.id) as completions,
                COALESCE(SUM(tc.points_earned), 0) as points
            FROM task_completions tc
            JOIN tasks t ON t.id = tc.task_id
            WHERE tc.user_id = :uid
              AND t.project_id = :pid
              AND tc.completed_at >= NOW() - INTERVAL '1 day' * :days
            GROUP BY completion_date
            ORDER BY completion_date DESC
            """),
            {"uid": str(user.user_id), "pid": str(project_id), "days": days},
        )
        return [dict(r._mapping) for r in result.fetchall()]
