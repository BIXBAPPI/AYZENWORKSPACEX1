# ID: AX79      |  Local: A56Y1         |  Module: X60 (M59)
# Functions: A56Y1F1 A56Y1F2 A56Y1F3 A56Y1F4
# Processes: XN01 XN02 XN03 XN04
from __future__ import annotations

import logging
from sqlalchemy import text
from uuid import UUID

from fastapi import APIRouter, Request

logger = logging.getLogger("ayzen.routers.analytics")

router = APIRouter()


async def _auth_admin(request: Request):
    from apps.api.app.middleware.auth import verify_token, require_admin
    user = await verify_token(request)
    await require_admin(user)
    return user


@router.get("/overview/{project_id}")
async def project_overview(project_id: UUID, request: Request) -> dict:
    """A56Y1F1: Full project analytics overview for admin dashboard."""
    user = await _auth_admin(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))

        result = await session.execute(
            text("""
            SELECT
                COUNT(DISTINCT t.id) as total_tasks,
                COUNT(DISTINCT pm.user_id) as total_members,
                COUNT(DISTINCT tc.id) as total_completions,
                COUNT(DISTINCT tc.user_id) as active_completors,
                COALESCE(SUM(tc.points_earned), 0) as total_points,
                COUNT(DISTINCT tc.id) FILTER (WHERE DATE(tc.completed_at) = CURRENT_DATE) as today_completions,
                COUNT(DISTINCT tc.id) FILTER (WHERE DATE(tc.completed_at) >= CURRENT_DATE - 7) as week_completions
            FROM projects p
            LEFT JOIN tasks t ON t.project_id = p.id AND t.archived_at IS NULL
            LEFT JOIN project_members pm ON pm.project_id = p.id
            LEFT JOIN task_completions tc ON tc.task_id = t.id
            WHERE p.id = :pid
            """),
            {"pid": str(project_id)},
        )
        overview = dict(result.fetchone()._mapping) if result.rowcount else {}

        # Task completion rates
        task_result = await session.execute(
            text("""
            SELECT t.id, t.title, t.task_type,
                   COUNT(tc.id) as completion_count,
                   COUNT(DISTINCT tc.user_id) as unique_users
            FROM tasks t
            LEFT JOIN task_completions tc ON tc.task_id = t.id
            WHERE t.project_id = :pid AND t.archived_at IS NULL
            GROUP BY t.id, t.title, t.task_type
            ORDER BY completion_count DESC
            LIMIT 10
            """),
            {"pid": str(project_id)},
        )
        top_tasks = [dict(r._mapping) for r in task_result.fetchall()]

    return {"overview": overview, "top_tasks": top_tasks}


@router.get("/timeseries/{project_id}")
async def timeseries(project_id: UUID, request: Request, days: int = 30) -> list[dict]:
    """A56Y1F2: Daily completion timeseries for charts."""
    user = await _auth_admin(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT
                DATE(tc.completed_at) as completion_date,
                COUNT(tc.id) as completions,
                COUNT(DISTINCT tc.user_id) as unique_users,
                COALESCE(SUM(tc.points_earned), 0) as total_points
            FROM task_completions tc
            JOIN tasks t ON t.id = tc.task_id
            WHERE t.project_id = :pid
              AND tc.completed_at >= NOW() - INTERVAL '1 day' * :days
            GROUP BY completion_date
            ORDER BY completion_date ASC
            """),
            {"pid": str(project_id), "days": days},
        )
        return [dict(r._mapping) for r in result.fetchall()]


@router.get("/members/{project_id}")
async def member_analytics(project_id: UUID, request: Request) -> list[dict]:
    """A56Y1F3: Per-member analytics for admin."""
    user = await _auth_admin(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT u.full_name, u.email, pm.role,
                   COUNT(tc.id) as completions,
                   COALESCE(SUM(tc.points_earned), 0) as total_points,
                   MAX(tc.completed_at) as last_active,
                   COUNT(tc.id) FILTER (WHERE DATE(tc.completed_at) = CURRENT_DATE) as today_completions
            FROM project_members pm
            JOIN users u ON u.id = pm.user_id
            LEFT JOIN task_completions tc ON tc.user_id = u.id
            JOIN tasks t ON t.id = tc.task_id AND t.project_id = :pid
            WHERE pm.project_id = :pid
            GROUP BY u.full_name, u.email, pm.role
            ORDER BY total_points DESC
            """),
            {"pid": str(project_id)},
        )
        return [dict(r._mapping) for r in result.fetchall()]


@router.get("/snapshots/{project_id}")
async def analytics_snapshots(project_id: UUID, request: Request, limit: int = 30) -> list[dict]:
    """A56Y1F4: Pre-computed analytics snapshots."""
    user = await _auth_admin(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT snapshot_date, completions, unique_users, total_points
            FROM analytics_snapshots
            WHERE project_id = :pid
            ORDER BY snapshot_date DESC
            LIMIT :limit
            """),
            {"pid": str(project_id), "limit": limit},
        )
        return [dict(r._mapping) for r in result.fetchall()]
