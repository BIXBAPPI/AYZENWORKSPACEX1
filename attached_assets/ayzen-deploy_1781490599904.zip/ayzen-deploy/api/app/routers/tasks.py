# ID: AX76      |  Local: A53Y1         |  Module: X57 (M56)
# Functions: A53Y1F1 A53Y1F2 A53Y1F3 A53Y1F4 A53Y1F5
# Processes: XN01 XN02 XN03 XN04 XN05
from __future__ import annotations

import logging
from sqlalchemy import text
from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel

logger = logging.getLogger("ayzen.routers.tasks")

router = APIRouter()


class CreateTaskRequest(BaseModel):
    project_id: UUID
    title: str
    task_type: str = "other"
    target_url: str | None = None
    points_per_account: int = 0
    deadline: datetime | None = None
    max_slots_per_user: int = 5


class UpdateTaskRequest(BaseModel):
    title: str | None = None
    target_url: str | None = None
    points_per_account: int | None = None
    deadline: datetime | None = None
    max_slots_per_user: int | None = None


async def _auth(request: Request):
    from apps.api.app.middleware.auth import verify_token
    return await verify_token(request)


@router.get("/")
async def list_tasks(request: Request, project_id: UUID | None = None) -> list[dict]:
    """A53Y1F1: List tasks for user."""
    user = await _auth(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        query = """
            SELECT t.id, t.title, t.task_type, t.target_url, t.points_per_account,
                   t.deadline, t.max_slots_per_user, t.created_at,
                   p.name as project_name,
                   COUNT(tc.id) FILTER (WHERE tc.user_id = :uid) as user_completions
            FROM tasks t
            JOIN projects p ON p.id = t.project_id
            JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = :uid
            LEFT JOIN task_completions tc ON tc.task_id = t.id
            WHERE t.archived_at IS NULL
        """
        params: dict = {"uid": str(user.user_id)}
        if project_id:
            query += " AND t.project_id = :pid"
            params["pid"] = str(project_id)
        query += " GROUP BY t.id, t.title, t.task_type, t.target_url, t.points_per_account, t.deadline, t.max_slots_per_user, t.created_at, p.name ORDER BY t.created_at DESC"

        result = await session.execute(query, params)
        return [dict(r._mapping) for r in result.fetchall()]


@router.post("/", status_code=201)
async def create_task(body: CreateTaskRequest, request: Request) -> dict:
    """A53Y1F2: Create task (admin only)."""
    user = await _auth(request)
    from apps.api.app.middleware.auth import require_admin
    await require_admin(user)

    db = request.app.state.db
    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            INSERT INTO tasks (project_id, title, task_type, target_url, points_per_account,
                               deadline, max_slots_per_user, created_by)
            VALUES (:pid, :title, :ttype, :url, :pts, :deadline, :max_slots, :uid)
            RETURNING id, title, task_type, target_url, points_per_account, deadline, created_at
            """),
            {
                "pid": str(body.project_id), "title": body.title, "ttype": body.task_type,
                "url": str(body.target_url) if body.target_url else None, "pts": body.points_per_account,
                "deadline": body.deadline, "max_slots": body.max_slots_per_user, "uid": str(user.user_id),
            },
        )
        task = dict(result.fetchone()._mapping)
        await session.commit()
    return task


@router.get("/{task_id}")
async def get_task(task_id: UUID, request: Request) -> dict:
    """A53Y1F3: Get task detail."""
    user = await _auth(request)
    db = request.app.state.db

    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        result = await session.execute(
            text("""
            SELECT t.id, t.title, t.task_type, t.target_url, t.points_per_account,
                   t.deadline, t.max_slots_per_user, t.created_at, p.name as project_name
            FROM tasks t
            JOIN projects p ON p.id = t.project_id
            JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = :uid
            WHERE t.id = :tid AND t.archived_at IS NULL
            """),
            {"tid": str(task_id), "uid": str(user.user_id)},
        )
        row = result.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="task_not_found")
        return dict(row._mapping)


@router.patch("/{task_id}")
async def update_task(task_id: UUID, body: UpdateTaskRequest, request: Request) -> dict:
    """A53Y1F4: Update task (admin only)."""
    user = await _auth(request)
    from apps.api.app.middleware.auth import require_admin
    await require_admin(user)

    db = request.app.state.db
    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        updates = {k: v for k, v in body.model_dump().items() if v is not None}
        if not updates:
            raise HTTPException(status_code=400, detail="no_updates")
        set_clauses = ", ".join(f"{k} = :{k}" for k in updates)
        updates["tid"] = str(task_id)
        result = await session.execute(
            text(f"UPDATE tasks SET {set_clauses}, updated_at = NOW() WHERE id = :tid RETURNING id, title"),
            updates,
        )
        await session.commit()
        row = result.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="task_not_found")
        return dict(row._mapping)


@router.delete("/{task_id}", status_code=204)
async def archive_task(task_id: UUID, request: Request) -> None:
    """A53Y1F5: Archive/soft-delete task."""
    user = await _auth(request)
    from apps.api.app.middleware.auth import require_admin
    await require_admin(user)
    db = request.app.state.db
    async with db() as session:
        await session.execute(text(f"SET LOCAL app.current_tenant = '{user.tenant_id}'"))
        await session.execute(
            text("UPDATE tasks SET archived_at = NOW() WHERE id = :tid"),
            {"tid": str(task_id)},
        )
        await session.commit()
