# ID: AX71      |  Local: A48Y1         |  Module: X52 (M51)
# Functions: A48Y1F1 A48Y1F2 A48Y1F3 A48Y1F4 A48Y1F5
# Processes: XN01 XN02 XN03 XN04 XN05
from __future__ import annotations

import logging
from sqlalchemy import text
import os

from fastapi import APIRouter, HTTPException, Request, Response, status
from pydantic import BaseModel, EmailStr

logger = logging.getLogger("ayzen.routers.auth")

router = APIRouter()

_SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
_SUPABASE_ANON_KEY = os.environ.get("SUPABASE_ANON_KEY", "")


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    invite_code: str | None = None


class LinkCodeResponse(BaseModel):
    code: str
    expires_in: int


# XN01  Register
@router.post("/register", status_code=201)
async def register(body: RegisterRequest, request: Request) -> dict:
    """A48Y1F1: Register new user via Supabase Auth."""
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{_SUPABASE_URL}/auth/v1/signup",
            json={"email": body.email, "password": body.password},
            headers={"apikey": _SUPABASE_ANON_KEY, "Content-Type": "application/json"},
        )
        if resp.status_code not in (200, 201):
            detail = resp.json().get("error_description") or "Registration failed"
            raise HTTPException(status_code=400, detail=detail)

        supabase_user = resp.json()
        user_id = supabase_user.get("user", {}).get("id")

        if user_id:
            db = request.app.state.db
            async with db() as session:
                # Create user record + default tenant
                await session.execute(
                    text("""
                    INSERT INTO users (id, email, full_name)
                    VALUES (:uid, :email, :name)
                    ON CONFLICT (id) DO NOTHING
                    """),
                    {"uid": user_id, "email": body.email, "name": body.full_name},
                )
                await session.commit()

    return {"status": "registered", "email": body.email}


# XN02  Login
@router.post("/login")
async def login(body: LoginRequest, response: Response) -> dict:
    """A48Y1F2: Login via Supabase, set HttpOnly cookie."""
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{_SUPABASE_URL}/auth/v1/token?grant_type=password",
            json={"email": body.email, "password": body.password},
            headers={"apikey": _SUPABASE_ANON_KEY, "Content-Type": "application/json"},
        )
        if resp.status_code != 200:
            detail = resp.json().get("error_description") or "Login failed"
            raise HTTPException(status_code=401, detail=detail)

        data = resp.json()
        access_token = data.get("access_token")
        refresh_token = data.get("refresh_token")

    # Set HttpOnly cookies
    response.set_cookie("sb-access-token", access_token, httponly=True, secure=True, samesite="strict", max_age=3600)
    response.set_cookie("sb-refresh-token", refresh_token, httponly=True, secure=True, samesite="strict", max_age=604800)

    return {"status": "logged_in"}


# XN03  Logout
@router.post("/logout")
async def logout(response: Response) -> dict:
    """A48Y1F3: Clear auth cookies."""
    response.delete_cookie("sb-access-token")
    response.delete_cookie("sb-refresh-token")
    return {"status": "logged_out"}


# XN04  Generate bot link code
@router.post("/bot-link-code", response_model=LinkCodeResponse)
async def generate_link_code(request: Request) -> LinkCodeResponse:
    """A48Y1F4: Generate a Telegram bot link code for authenticated user."""
    from apps.api.app.middleware.auth import verify_token
    from apps.api.app.services.bot_user_service import BotUserService

    user = await verify_token(request)

    redis = request.app.state.redis
    db = request.app.state.db

    svc = BotUserService(redis, db)
    code = await svc.generate_link_code(user.user_id)

    return LinkCodeResponse(code=code, expires_in=600)


# XN05  Session check
@router.get("/me")
async def me(request: Request) -> dict:
    """A48Y1F5: Return current user info."""
    from apps.api.app.middleware.auth import verify_token
    user = await verify_token(request)
    return {
        "user_id": str(user.user_id),
        "email": user.email,
        "role": user.role,
        "tenant_id": str(user.tenant_id),
    }
