# ID: AX72      |  Local: A49Y1         |  Module: X53 (M52)
# Functions: A49Y1F1 A49Y1F2 A49Y1F3 A49Y1F4
# Processes: XN01 XN02 XN03 XN04
from __future__ import annotations

import logging
from sqlalchemy import text
import os
from typing import Any
from uuid import UUID

import jwt
from fastapi import HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

logger = logging.getLogger("ayzen.auth")

_SUPABASE_JWT_SECRET = os.environ.get("SUPABASE_JWT_SECRET", "")
_bearer = HTTPBearer(auto_error=False)


class AuthUser:
    __slots__ = ("user_id", "tenant_id", "email", "role")

    def __init__(self, user_id: str, tenant_id: str, email: str, role: str) -> None:
        self.user_id = UUID(user_id)
        self.tenant_id = UUID(tenant_id)
        self.email = email
        self.role = role


# XN01  Verify JWT
async def verify_token(request: Request) -> AuthUser:
    """
    Validate Supabase JWT from HttpOnly cookie or Authorization header.
    Raises 401 on failure.
    """
    token: str | None = None

    # Check HttpOnly cookie first
    token = request.cookies.get("sb-access-token")

    # Fall back to Authorization header
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]

    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="not_authenticated")

    try:
        payload = jwt.decode(
            token,
            _SUPABASE_JWT_SECRET,
            algorithms=["HS256"],
            options={"verify_exp": True},
        )
        user_id = payload.get("sub")
        email = payload.get("email", "")

        if not user_id:
            raise ValueError("Missing sub in JWT")

        # Load tenant and role from DB
        db = request.app.state.db
        async with db() as session:
            result = await session.execute(
                text("SELECT id, tenant_id, role FROM users WHERE id = :uid"),
                {"uid": user_id},
            )
            row = result.fetchone()
            if not row:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="user_not_found")

            # Set tenant context for RLS
            await session.execute(text(f"SET LOCAL app.current_tenant = '{row.tenant_id}'"))

        return AuthUser(
            user_id=str(row.id),
            tenant_id=str(row.tenant_id),
            email=email,
            role=row.role,
        )

    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="token_expired")
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="token_invalid")
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Auth error: %s", exc)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="auth_error")


# XN02  Require Admin Role
async def require_admin(user: AuthUser) -> AuthUser:
    """Raise 403 if user is not owner or manager."""
    if user.role not in ("owner", "manager"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="admin_required")
    return user


# XN03  Optional auth (returns None if unauthenticated)
async def optional_auth(request: Request) -> AuthUser | None:
    try:
        return await verify_token(request)
    except HTTPException:
        return None


# XN04  Set tenant in DB session
async def set_tenant_context(session: Any, tenant_id: UUID) -> None:
    await session.execute(text(f"SET LOCAL app.current_tenant = '{tenant_id}'"))
