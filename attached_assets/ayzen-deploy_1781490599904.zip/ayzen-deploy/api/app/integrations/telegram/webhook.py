# ID: AX18      |  Local: A4Y5          |  Module: X05 (M04)
# Functions: A4Y5F1 A4Y5F2 A4Y5F3
# Processes: XN05
from __future__ import annotations

import logging
import os

from fastapi import APIRouter, Header, Request, Response
from fastapi.responses import JSONResponse

logger = logging.getLogger("ayzen.telegram.webhook")

router = APIRouter()

_INTERNAL_TOKEN = os.environ.get("INTERNAL_WEBHOOK_TOKEN", "")


def _token_valid(
    x_internal: str | None,
    x_telegram: str | None,
) -> bool:
    """
    Accept the request when:
    - No INTERNAL_WEBHOOK_TOKEN is configured (open to all, good for direct Telegram).
    - OR the X-Internal-Webhook-Token header matches (Cloudflare Worker path).
    - OR the X-Telegram-Bot-Api-Secret-Token header matches (native Telegram secret_token).
    """
    if not _INTERNAL_TOKEN:
        return True
    if x_internal and x_internal == _INTERNAL_TOKEN:
        return True
    if x_telegram and x_telegram == _INTERNAL_TOKEN:
        return True
    return False


@router.post("/bot/webhook")
async def webhook_handler(
    request: Request,
    x_internal_webhook_token: str | None = Header(None, alias="X-Internal-Webhook-Token"),
    x_telegram_bot_api_secret_token: str | None = Header(None, alias="X-Telegram-Bot-Api-Secret-Token"),
) -> Response:
    """
    XN05: Telegram webhook entry point.
    - Validates token via X-Internal-Webhook-Token (CF Worker) or
      X-Telegram-Bot-Api-Secret-Token (native Telegram secret_token).
    - Parses Update JSON and dispatches to BotRouter.
    - ALWAYS returns 200 — Telegram retries on non-200.
    """
    if not _token_valid(x_internal_webhook_token, x_telegram_bot_api_secret_token):
        logger.warning("Invalid webhook token — rejecting update")
        return Response(status_code=200)

    update: dict = {}
    try:
        update = await request.json()
    except Exception as exc:
        logger.warning("Failed to parse webhook JSON: %s", exc)
        return Response(status_code=200)

    try:
        bot_router = get_bot_router(request.app)
        await bot_router.dispatch(update)
    except Exception as exc:
        logger.exception("Unhandled error in webhook dispatch: %s", exc)
        try:
            from apps.api.app.services.bot_audit_service import BotAuditService
            audit = BotAuditService(request.app.state.db)
            await audit.log(
                user_id=None,
                tenant_id=None,
                action="webhook_error",
                payload={"error": str(exc), "update": update},
            )
        except Exception:
            pass

    return Response(status_code=200)


@router.post("/bot/set-webhook")
async def set_webhook(request: Request) -> JSONResponse:
    """
    A4Y5F3: Manually (re-)register the Telegram webhook.
    Reads WEBHOOK_BASE_URL + TELEGRAM_BOT_TOKEN + INTERNAL_WEBHOOK_TOKEN from env.
    Call this after changing your domain or rotating the secret token.
    """
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    base_url = os.environ.get("WEBHOOK_BASE_URL", "").rstrip("/")

    if not token:
        return JSONResponse(status_code=500, content={"error": "TELEGRAM_BOT_TOKEN not set"})
    if not base_url:
        return JSONResponse(status_code=500, content={"error": "WEBHOOK_BASE_URL not set — add it to Replit Secrets (e.g. https://ayzen.tech)"})

    webhook_url = f"{base_url}/api/v1/bot/webhook"
    secret_token = os.environ.get("INTERNAL_WEBHOOK_TOKEN", "")

    payload: dict = {
        "url": webhook_url,
        "allowed_updates": ["message", "callback_query", "inline_query"],
    }
    if secret_token:
        payload["secret_token"] = secret_token

    try:
        import httpx
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"https://api.telegram.org/bot{token}/setWebhook",
                json=payload,
            )
            data = resp.json()
            if data.get("ok"):
                logger.info("Webhook set to %s", webhook_url)
                return JSONResponse({"ok": True, "webhook_url": webhook_url})
            else:
                logger.error("setWebhook failed: %s", data)
                return JSONResponse(status_code=502, content={"ok": False, "telegram": data})
    except Exception as exc:
        logger.exception("set-webhook error: %s", exc)
        return JSONResponse(status_code=500, content={"error": str(exc)})


def get_bot_router(app: object) -> object:
    """A4Y5F2: Get or lazily create the BotRouter singleton from app state."""
    if not hasattr(app.state, "bot_router"):
        from apps.api.app.integrations.telegram.client import get_telegram_client
        from apps.api.app.services.bot_state_service import BotStateService
        from apps.api.app.integrations.telegram.middleware.rate_limit import TelegramRateLimiter
        from apps.api.app.integrations.telegram.middleware.idempotency import IdempotencyGuard
        from apps.api.app.integrations.telegram.router import BotRouter

        redis = getattr(app.state, "redis", None)
        db    = app.state.db
        client = get_telegram_client()

        bot_router = BotRouter(
            state_service=BotStateService(redis, db),
            rate_limiter=TelegramRateLimiter(redis),
            idempotency=IdempotencyGuard(redis, db),
            telegram_client=client,
            app=app,
        )
        _register_all_handlers(bot_router)
        app.state.bot_router = bot_router

    return app.state.bot_router


def _register_all_handlers(r: object) -> None:  # noqa: C901
    """Wire every command, callback prefix, and state handler into the router."""

    # ── Core / Auth ──────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.start import (
        start_handler, link_handler,
    )

    # ── Menu ─────────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.menu import (
        menu_handler, cancel_handler, menu_callback_handler, menu_text_handler,
    )

    # ── Basic info ────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.help import help_handler
    from apps.api.app.integrations.telegram.handlers.status import status_handler
    from apps.api.app.integrations.telegram.handlers.profile import (
        profile_handler, profile_refresh_callback,
    )

    # ── Projects ──────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.projects import (
        projects_handler, project_select_callback,
        project_page_callback, project_detail_callback,
    )

    # ── Tasks ─────────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.tasks import (
        tasks_handler, task_page_callback, task_filter_callback,
        task_detail_callback, task_action_callback,
    )

    # ── Submit ────────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.submit_single import (
        submit_single_entry, slot_select_callback, confirm_submit_callback,
    )
    from apps.api.app.integrations.telegram.handlers.submit_batch import (
        batch_submit_entry, toggle_slot_callback,
        confirm_batch_callback, cancel_batch_callback,
    )

    # ── Settings ──────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.settings import (
        settings_handler, settings_callback,
        settings_language_handler, settings_notifications_handler,
        settings_quiet_hours_handler, unlink_handler,
    )

    # ── Analytics ─────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.analytics import (
        analytics_handler, analytics_today_handler,
        analytics_week_handler, analytics_month_handler,
        analytics_callback_handler,
    )

    # ── Leaderboard ───────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.leaderboard import (
        leaderboard_handler, leaderboard_callback,
    )

    # ── Points / Wallet ───────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.wallet import (
        wallet_balance_handler, wallet_history_handler,
        wallet_breakdown_handler, wallet_callback_handler,
    )

    # ── Achievements / Badges ─────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.achievements import (
        achievements_handler, badge_callback_handler,
        streak_handler, milestones_handler,
    )

    # ── Search ────────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.search import (
        search_prompt_handler, search_execute_handler, search_callback_handler,
    )

    # ── Pins ──────────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.pins import (
        pins_handler, pin_callback_handler,
    )

    # ── Referral ──────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.referral import (
        referral_handler, referral_callback_handler,
    )

    # ── Admin ─────────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.admin.panel import (
        admin_panel_handler, admin_action_callback, admin_export_handler,
    )
    from apps.api.app.integrations.telegram.handlers.admin.members import (
        admin_members_handler, admin_member_action_callback,
    )

    # ── Inline query ──────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.handlers.inline_query import inline_query_handler

    # ── Wizards ───────────────────────────────────────────────────────────────
    from apps.api.app.integrations.telegram.wizards.task_create import (
        wizard_task_start, wizard_task_step_handler, wizard_task_cancel,
        task_create_start,
    )
    from apps.api.app.integrations.telegram.wizards.slot_setup import (
        wizard_slot_start, wizard_slot_step_handler,
    )
    from apps.api.app.integrations.telegram.wizards.broadcast import (
        broadcast_wizard_start, broadcast_wizard_step,
        broadcast_start,
    )
    from apps.api.app.integrations.telegram.wizards.owner_transfer import (
        transfer_start_handler, transfer_candidate_callback,
        transfer_confirm_callback, transfer_typed_handler,
    )

    # ════════════════════════════════════════════════════════════════════════
    # COMMANDS
    # ════════════════════════════════════════════════════════════════════════
    r.register_command("start",        start_handler)
    r.register_command("link",         link_handler)
    r.register_command("menu",         menu_handler)
    r.register_command("help",         help_handler)
    r.register_command("status",       status_handler)
    r.register_command("cancel",       cancel_handler)
    r.register_command("settings",     settings_handler)
    r.register_command("profile",      profile_handler)
    r.register_command("analytics",    analytics_week_handler)
    r.register_command("leaderboard",  leaderboard_handler)
    r.register_command("points",       wallet_balance_handler)
    r.register_command("badges",       achievements_handler)
    r.register_command("search",       search_prompt_handler)
    r.register_command("pinned",       pins_handler)
    r.register_command("referral",     referral_handler)
    r.register_command("transfer",     transfer_start_handler)

    # Internal routing keys
    r.register_command("menu_text",    menu_text_handler)
    r.register_command("inline_query", inline_query_handler)

    # ════════════════════════════════════════════════════════════════════════
    # CALLBACK PREFIXES  (most-specific first within each group)
    # ════════════════════════════════════════════════════════════════════════

    # Navigation
    r.register_callback_prefix("menu:",             menu_callback_handler)

    # Projects
    r.register_callback_prefix("project:",          project_select_callback)
    r.register_callback_prefix("proj_page:",        project_page_callback)
    r.register_callback_prefix("proj_detail:",      project_detail_callback)

    # Tasks + filters
    r.register_callback_prefix("task_action:",      task_action_callback)
    r.register_callback_prefix("task_filter:",      task_filter_callback)
    r.register_callback_prefix("task_page:",        task_page_callback)
    r.register_callback_prefix("task:",             task_detail_callback)   # catch-all last

    # Submit
    r.register_callback_prefix("confirm_submit:",   confirm_submit_callback)
    r.register_callback_prefix("batch_confirm:",    confirm_batch_callback)
    r.register_callback_prefix("batch_cancel:",     cancel_batch_callback)
    r.register_callback_prefix("batch:",            toggle_slot_callback)
    r.register_callback_prefix("submit:",           slot_select_callback)

    # Settings + notifications + quiet hours + unlink
    r.register_callback_prefix("notify:",           settings_callback)
    r.register_callback_prefix("qh:",               settings_callback)
    r.register_callback_prefix("unlink:",           settings_callback)
    r.register_callback_prefix("settings:",         settings_callback)

    # Analytics
    r.register_callback_prefix("analytics:",        analytics_callback_handler)
    r.register_callback_prefix("leaderboard:",      leaderboard_callback)

    # Points / Wallet
    r.register_callback_prefix("points:",           wallet_callback_handler)

    # Achievements / Badges / Milestones
    r.register_callback_prefix("badge:",            badge_callback_handler)
    r.register_callback_prefix("milestone:",        badge_callback_handler)

    # Search
    r.register_callback_prefix("search:",           search_callback_handler)

    # Pins
    r.register_callback_prefix("pin:",              pin_callback_handler)

    # Referral
    r.register_callback_prefix("referral:",         referral_callback_handler)

    # Admin
    r.register_callback_prefix("admin_member:",     admin_member_action_callback)
    r.register_callback_prefix("admin:",            admin_action_callback)
    r.register_callback_prefix("export:",           admin_export_handler)

    # Profile
    r.register_callback_prefix("profile_refresh:",  profile_refresh_callback)

    # Owner transfer
    r.register_callback_prefix("transfer_to:",      transfer_candidate_callback)
    r.register_callback_prefix("transfer:",         transfer_confirm_callback)

    # Wizard controls
    r.register_callback_prefix("wizard_cancel:",    wizard_task_cancel)
    r.register_callback_prefix("wizard_slot:",      wizard_slot_start)
    r.register_callback_prefix("broadcast_wizard:", broadcast_wizard_start)

    # Confirm / cancel generics (must be last — broad prefix)
    r.register_callback_prefix("confirm:",          menu_callback_handler)

    # ════════════════════════════════════════════════════════════════════════
    # STATE HANDLERS  (wizard text-input states)
    # ════════════════════════════════════════════════════════════════════════
    r.register_state_handler("WIZARD_NEW_TASK",         wizard_task_step_handler)
    r.register_state_handler("WIZARD_NEW_SLOT",         wizard_slot_step_handler)
    r.register_state_handler("WIZARD_BROADCAST",        broadcast_wizard_step)
    r.register_state_handler("SEARCH_WAIT",             search_execute_handler)
    r.register_state_handler("OWNER_TRANSFER_SELECT",   transfer_start_handler)
    r.register_state_handler("OWNER_TRANSFER_CONFIRM",  transfer_confirm_callback)
    r.register_state_handler("OWNER_TRANSFER_TYPED",    transfer_typed_handler)
