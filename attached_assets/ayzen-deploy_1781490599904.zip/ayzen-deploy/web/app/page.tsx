// ID: AX03      |  Local: A1Y3          |  Module: X02 (M01)
// Functions: A1Y3F1
import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4"
          style={{ background: "linear-gradient(135deg, #0f0f11 0%, #1a1a2e 50%, #0f0f11 100%)" }}>
      {/* Hero */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm mb-8"
             style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.3)", color: "#a78bfa" }}>
          🤖 Telegram Bot + Web Dashboard
        </div>

        <h1 className="text-5xl font-bold mb-6" style={{ color: "#e8e8f0" }}>
          <span style={{ color: "#6366f1" }}>AYZEN</span>
          <br />
          Crypto Task Platform
        </h1>

        <p className="text-lg mb-10" style={{ color: "#94a3b8" }}>
          Manage crypto community tasks, track multi-account completions,
          and coordinate your team — entirely through Telegram.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/auth/register"
            className="px-8 py-3 rounded-lg font-semibold text-white transition-all"
            style={{ background: "#6366f1" }}
          >
            Get Started →
          </Link>
          <Link
            href="/auth/login"
            className="px-8 py-3 rounded-lg font-semibold transition-all"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#e8e8f0" }}
          >
            Sign In
          </Link>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl w-full mt-20 px-4">
        {[
          { icon: "🤖", title: "Telegram Bot", desc: "Submit tasks, check progress, and receive notifications — all from Telegram." },
          { icon: "📊", title: "Web Dashboard", desc: "Admin panel with analytics, member management, and CSV exports." },
          { icon: "⚡", title: "Multi-Account", desc: "Manage multiple wallet/Twitter/Discord slots per member." },
        ].map((f) => (
          <div key={f.title} className="p-6 rounded-xl text-center"
               style={{ background: "rgba(99,102,241,0.07)", border: "1px solid rgba(99,102,241,0.2)" }}>
            <div className="text-3xl mb-3">{f.icon}</div>
            <h3 className="font-semibold mb-2" style={{ color: "#e8e8f0" }}>{f.title}</h3>
            <p className="text-sm" style={{ color: "#64748b" }}>{f.desc}</p>
          </div>
        ))}
      </div>

      <footer className="mt-16 text-sm" style={{ color: "#475569" }}>
        © 2026 AYZEN · Built for crypto communities
      </footer>
    </main>
  );
}
