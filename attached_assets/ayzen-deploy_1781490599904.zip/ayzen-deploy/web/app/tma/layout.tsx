// ID: AX66      |  Local: A43Y1         |  Module: X47 (M46)
// Functions: A43Y1F1
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "AYZEN Mini App",
  description: "AYZEN Telegram Mini App",
};

export default function TmaLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--tg-theme-bg-color, #0f0f11)",
        color: "var(--tg-theme-text-color, #e8e8f0)",
        fontFamily: "var(--font-geist-sans), system-ui, sans-serif",
        padding: 0,
        margin: 0,
      }}
    >
      {children}
    </div>
  );
}
