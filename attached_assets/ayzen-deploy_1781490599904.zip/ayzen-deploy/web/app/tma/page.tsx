// ID: AX67      |  Local: A43Y2         |  Module: X47 (M46)
// Functions: A43Y2F1 A43Y2F2 A43Y2F3
"use client";

import { useEffect, useState } from "react";

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData: string;
        initDataUnsafe: {
          user?: { id: number; first_name: string; username?: string; language_code?: string };
          start_param?: string;
        };
        ready: () => void;
        expand: () => void;
        MainButton: { text: string; show: () => void; hide: () => void; onClick: (fn: () => void) => void };
        BackButton: { show: () => void; hide: () => void; onClick: (fn: () => void) => void };
        close: () => void;
        themeParams: Record<string, string>;
      };
    };
  }
}

interface TmaUser {
  status: "linked" | "not_linked";
  full_name?: string;
  role?: string;
  locale?: string;
  telegram_user_id?: number;
  first_name?: string;
}

export default function TmaPage() {
  const [user, setUser] = useState<TmaUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
    }

    const initData = tg?.initData || "";
    const API = process.env.NEXT_PUBLIC_API_URL || "";

    fetch(`${API}/api/v1/tma/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ init_data: initData }),
      credentials: "include",
    })
      .then((r) => r.json())
      .then((data: TmaUser) => {
        setUser(data);
        setLoading(false);
      })
      .catch((err) => {
        setError("Failed to authenticate. Please restart the app.");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div style={{ color: "#a78bfa" }}>⏳ Loading AYZEN...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <p style={{ color: "#ef4444" }}>{error}</p>
      </div>
    );
  }

  if (user?.status === "not_linked") {
    return (
      <div className="p-6 flex flex-col items-center gap-6 min-h-screen justify-center">
        <div className="text-5xl">🔗</div>
        <h2 className="text-xl font-bold">Link your account</h2>
        <p className="text-center text-sm" style={{ color: "#94a3b8" }}>
          To use AYZEN, link your Telegram to your web account.
          Use <strong>/link &lt;code&gt;</strong> in the bot after generating a code on the dashboard.
        </p>
        <a
          href="/"
          style={{
            padding: "12px 24px",
            background: "#6366f1",
            borderRadius: "8px",
            color: "white",
            fontWeight: 600,
            textDecoration: "none",
          }}
        >
          Go to Dashboard →
        </a>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
               style={{ background: "rgba(99,102,241,0.2)" }}>
            👤
          </div>
          <div>
            <div className="font-semibold">{user?.full_name}</div>
            <div className="text-xs" style={{ color: "#64748b" }}>{user?.role}</div>
          </div>
        </div>
      </div>

      <div className="grid gap-3">
        <a href="/tma/tasks" className="p-4 rounded-xl flex items-center gap-4"
           style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)" }}>
          <span className="text-2xl">📋</span>
          <div>
            <div className="font-medium">Tasks</div>
            <div className="text-xs" style={{ color: "#64748b" }}>View &amp; submit tasks</div>
          </div>
          <span className="ml-auto">→</span>
        </a>
      </div>
    </div>
  );
}
