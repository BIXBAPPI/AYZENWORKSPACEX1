// ID: AX69      |  Local: A46Y1         |  Module: X50 (M49)
// Functions: A46Y1F1 A46Y1F2 A46Y1F3
"use client";

import { useEffect, useState } from "react";

interface Task {
  id: string;
  title: string;
  task_type: string;
  points_per_account: number;
  deadline?: string;
  target_url?: string;
  user_completions: number;
}

const TYPE_EMOJI: Record<string, string> = {
  twitter: "🐦",
  discord: "💬",
  onchain: "🔗",
  form: "📝",
  other: "📋",
};

export default function TmaTasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  const API = process.env.NEXT_PUBLIC_API_URL || "";

  useEffect(() => {
    fetch(`${API}/api/v1/tasks/`, { credentials: "include" })
      .then((r) => r.json())
      .then((data) => {
        setTasks(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="p-6 text-center" style={{ color: "#a78bfa" }}>
        ⏳ Loading tasks...
      </div>
    );
  }

  if (tasks.length === 0) {
    return (
      <div className="p-6 text-center">
        <div className="text-3xl mb-3">📭</div>
        <p style={{ color: "#64748b" }}>No tasks available right now.</p>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => history.back()} style={{ color: "#a78bfa", fontSize: "20px" }}>←</button>
        <h1 className="font-bold text-lg">Tasks</h1>
      </div>

      <div className="flex flex-col gap-3">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="p-4 rounded-xl"
            style={{
              background: "rgba(99,102,241,0.08)",
              border: "1px solid rgba(99,102,241,0.2)",
            }}
          >
            <div className="flex items-start gap-3">
              <span className="text-2xl">{TYPE_EMOJI[task.task_type] ?? "📋"}</span>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{task.title}</div>
                <div className="flex gap-3 mt-1 text-xs" style={{ color: "#64748b" }}>
                  <span>💰 {task.points_per_account} pts</span>
                  {task.deadline && (
                    <span>⏰ {new Date(task.deadline).toLocaleDateString()}</span>
                  )}
                </div>
              </div>
              {task.user_completions > 0 && (
                <span className="text-xs px-2 py-1 rounded-full"
                      style={{ background: "rgba(34,197,94,0.15)", color: "#22c55e" }}>
                  ✅ Done
                </span>
              )}
            </div>
            {task.target_url && (
              <a
                href={task.target_url}
                target="_blank"
                rel="noreferrer"
                className="mt-3 block text-center py-2 rounded-lg text-sm font-medium"
                style={{ background: "#6366f1", color: "white" }}
              >
                Go to Task →
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
