// ID: AX82      |  Local: A59Y1         |  Module: X63 (M62)
// Functions: A59Y1F1 A59Y1F2 A59Y1F3
"use client";

import { useState } from "react";

type ExportType = "completions" | "members" | "slots";

interface ExportOption {
  type: ExportType;
  label: string;
  icon: string;
  desc: string;
}

const EXPORT_OPTIONS: ExportOption[] = [
  { type: "completions", label: "Task Completions", icon: "✅", desc: "All task completions with user, slot, and points data." },
  { type: "members", label: "Members List", icon: "👥", desc: "Project member directory with roles and completion counts." },
  { type: "slots", label: "Account Slots", icon: "🔑", desc: "All Twitter, Discord, and wallet addresses per member." },
];

export default function ExportsPage() {
  const [projectId, setProjectId] = useState("");
  const [exporting, setExporting] = useState<ExportType | null>(null);

  const API = process.env.NEXT_PUBLIC_API_URL || "";

  async function handleExport(type: ExportType) {
    if (!projectId.trim()) {
      alert("Please enter a project ID");
      return;
    }
    setExporting(type);
    try {
      const res = await fetch(`${API}/api/v1/exports/${type}/${projectId}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Export failed");

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${type}_${projectId}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert("Export failed. Check project ID and permissions.");
    } finally {
      setExporting(null);
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-2" style={{ color: "var(--foreground)" }}>
        📥 Exports
      </h1>
      <p className="mb-6 text-sm" style={{ color: "var(--muted)" }}>
        Download project data as CSV for offline analysis.
      </p>

      {/* Project ID Input */}
      <div className="mb-8 p-4 rounded-xl" style={{ background: "var(--surface)", border: "1px solid var(--border)" }}>
        <label className="block text-sm font-medium mb-2" style={{ color: "var(--foreground)" }}>
          Project ID
        </label>
        <input
          type="text"
          value={projectId}
          onChange={(e) => setProjectId(e.target.value)}
          placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
          className="w-full px-4 py-2 rounded-lg text-sm font-mono"
          style={{
            background: "var(--surface-2)",
            border: "1px solid var(--border)",
            color: "var(--foreground)",
            outline: "none",
          }}
        />
      </div>

      {/* Export Cards */}
      <div className="space-y-4">
        {EXPORT_OPTIONS.map((opt) => (
          <div
            key={opt.type}
            className="p-5 rounded-xl flex items-center justify-between gap-4"
            style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
          >
            <div className="flex items-start gap-4">
              <div className="text-2xl">{opt.icon}</div>
              <div>
                <div className="font-medium" style={{ color: "var(--foreground)" }}>{opt.label}</div>
                <div className="text-sm mt-0.5" style={{ color: "var(--muted)" }}>{opt.desc}</div>
              </div>
            </div>
            <button
              onClick={() => handleExport(opt.type)}
              disabled={exporting === opt.type}
              className="shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: exporting === opt.type ? "var(--surface-2)" : "var(--primary)",
                color: "white",
                cursor: exporting === opt.type ? "wait" : "pointer",
              }}
            >
              {exporting === opt.type ? "Exporting..." : "Download CSV"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
