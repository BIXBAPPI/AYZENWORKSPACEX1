// ID: AX88      |  Local: A65Y1         |  Module: X69 (M68)
// Functions: A65Y1F1 A65Y1F2 A65Y1F3
import { getCurrentUser } from "@/lib/auth-server";
import { redirect } from "next/navigation";

const API = process.env.NEXT_PUBLIC_API_URL || "";

async function getOnboardingStatus() {
  try {
    const res = await fetch(`${API}/api/v1/auth/me`, { cache: "no-store" });
    return res.ok ? await res.json() : null;
  } catch {
    return null;
  }
}

interface Step {
  key: string;
  label: string;
  icon: string;
  desc: string;
  href?: string;
}

const STEPS: Step[] = [
  {
    key: "create_project",
    label: "Create your first project",
    icon: "📁",
    desc: "Organize your community tasks under a project.",
    href: "/dashboard/projects",
  },
  {
    key: "create_task",
    label: "Add a task",
    icon: "📋",
    desc: "Create Twitter, Discord, or on-chain tasks for your members.",
    href: "/dashboard/tasks",
  },
  {
    key: "add_member",
    label: "Invite a member",
    icon: "👥",
    desc: "Add team members who will complete tasks.",
    href: "/dashboard/members",
  },
  {
    key: "link_bot",
    label: "Link Telegram Bot",
    icon: "🤖",
    desc: "Generate a link code and use /link in the bot.",
    href: "/dashboard/settings",
  },
];

export default async function OnboardingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/auth/login");

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <div className="text-5xl mb-4">🚀</div>
        <h1 className="text-3xl font-bold mb-2" style={{ color: "var(--foreground)" }}>
          Welcome to AYZEN
        </h1>
        <p style={{ color: "var(--muted)" }}>
          Complete these steps to get your platform ready.
        </p>
      </div>

      <div className="space-y-4">
        {STEPS.map((step, idx) => (
          <a
            key={step.key}
            href={step.href || "#"}
            className="flex items-center gap-5 p-5 rounded-xl transition-all"
            style={{
              background: "var(--surface)",
              border: "1px solid var(--border)",
              textDecoration: "none",
            }}
          >
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0"
              style={{ background: "rgba(99,102,241,0.15)", color: "var(--primary)" }}
            >
              {idx + 1}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 font-medium" style={{ color: "var(--foreground)" }}>
                <span>{step.icon}</span>
                <span>{step.label}</span>
              </div>
              <div className="text-sm mt-0.5" style={{ color: "var(--muted)" }}>{step.desc}</div>
            </div>
            <span style={{ color: "var(--muted)" }}>→</span>
          </a>
        ))}
      </div>

      <div className="mt-8 text-center">
        <a href="/dashboard" className="text-sm" style={{ color: "var(--primary)" }}>
          Skip onboarding → Go to Dashboard
        </a>
      </div>
    </div>
  );
}
