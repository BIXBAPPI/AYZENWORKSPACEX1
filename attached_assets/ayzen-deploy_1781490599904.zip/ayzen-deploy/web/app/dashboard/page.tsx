import { redirect } from "next/navigation";

// Redirect /dashboard to the exports section (main dashboard page)
export default function DashboardRoot() {
  redirect("/dashboard/exports");
}
