// ID: AX89      |  Local: A66Y1         |  Module: X70 (M69)
// Functions: A66Y1F1 A66Y1F2 A66Y1F3

// AYZEN Design Tokens — single source of truth for all color/spacing values.
// Referenced in globals.css via CSS variables; this file provides typed access.

export const tokens = {
  colors: {
    background: "#0f0f11",
    foreground: "#e8e8f0",
    surface: "#1a1a2e",
    surface2: "#22223b",
    border: "#2d2d4a",
    primary: "#6366f1",
    primaryHover: "#4f46e5",
    accent: "#a78bfa",
    success: "#22c55e",
    warning: "#f59e0b",
    danger: "#ef4444",
    muted: "#64748b",
  },
  typography: {
    fontSans: "var(--font-geist-sans), system-ui, sans-serif",
    fontMono: "var(--font-geist-mono), ui-monospace, monospace",
    sizeSm: "0.875rem",
    sizeBase: "1rem",
    sizeLg: "1.125rem",
    sizeXl: "1.25rem",
    size2xl: "1.5rem",
  },
  spacing: {
    xs: "4px",
    sm: "8px",
    md: "16px",
    lg: "24px",
    xl: "32px",
    "2xl": "48px",
  },
  radii: {
    sm: "4px",
    md: "8px",
    lg: "12px",
    xl: "16px",
    full: "9999px",
  },
  shadows: {
    sm: "0 1px 3px 0 rgba(0,0,0,0.4)",
    md: "0 4px 6px -1px rgba(0,0,0,0.5)",
    glow: "0 0 20px rgba(99,102,241,0.3)",
  },
} as const;

// Task type display helpers
export const TASK_TYPE_META: Record<string, { emoji: string; label: string; color: string }> = {
  twitter:  { emoji: "🐦", label: "Twitter",  color: "#1DA1F2" },
  discord:  { emoji: "💬", label: "Discord",  color: "#5865F2" },
  onchain:  { emoji: "🔗", label: "On-Chain", color: "#F7931A" },
  form:     { emoji: "📝", label: "Form",     color: "#22c55e" },
  other:    { emoji: "📋", label: "Other",    color: "#64748b" },
};

// Role display helpers
export const ROLE_META: Record<string, { label: string; color: string; icon: string }> = {
  owner:   { label: "Owner",   color: "#f59e0b", icon: "👑" },
  manager: { label: "Manager", color: "#6366f1", icon: "🔑" },
  member:  { label: "Member",  color: "#64748b", icon: "👤" },
};

// Status badge styles
export function getStatusStyle(status: "ok" | "error" | "warning" | "disabled") {
  const map = {
    ok:       { bg: "rgba(34,197,94,0.15)",  color: "#22c55e", label: "OK" },
    error:    { bg: "rgba(239,68,68,0.15)",  color: "#ef4444", label: "Error" },
    warning:  { bg: "rgba(245,158,11,0.15)", color: "#f59e0b", label: "Warning" },
    disabled: { bg: "rgba(100,116,139,0.1)", color: "#64748b", label: "Disabled" },
  };
  return map[status] ?? map.disabled;
}
