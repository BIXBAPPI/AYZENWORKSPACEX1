import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// Internal API URL for server-side calls (avoids going through the proxy)
const INTERNAL_API_URL =
  process.env.INTERNAL_API_URL || process.env.NEXT_PUBLIC_API_URL || "";

// Server client (server components, route handlers)
export async function createServerClientInstance() {
  const cookieStore = await cookies();
  return createServerClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) =>
            cookieStore.set(name, value, options)
          );
        } catch {
          // Server Component — cookies can't be set here, handled by middleware
        }
      },
    },
  });
}

// Get current session server-side
export async function getSession() {
  const supabase = await createServerClientInstance();
  const {
    data: { session },
  } = await supabase.auth.getSession();
  return session;
}

// Get current user server-side (with DB role)
export async function getCurrentUser() {
  const session = await getSession();
  if (!session) return null;

  try {
    const res = await fetch(`${INTERNAL_API_URL}/api/v1/auth/me`, {
      headers: { Cookie: `sb-access-token=${session.access_token}` },
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}
