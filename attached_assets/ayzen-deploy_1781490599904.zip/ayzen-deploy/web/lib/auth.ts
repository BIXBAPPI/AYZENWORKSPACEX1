import { createBrowserClient } from "@supabase/ssr";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// Browser client (client components only)
export function createClient() {
  return createBrowserClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

// Sign out from both Supabase and API
export async function signOut() {
  const supabase = createClient();
  await supabase.auth.signOut();
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "";
  await fetch(`${apiUrl}/api/v1/auth/logout`, {
    method: "POST",
    credentials: "include",
  });
}
