// ID: AX86      |  Local: A63Y1         |  Module: X67 (M66)
// Functions: A63Y1F1 A63Y1F2 A63Y1F3
"use client";

import { useState } from "react";
import { signOut } from "@/lib/auth";
import { useRouter } from "next/navigation";

interface TopbarProps {
  user: { role?: string; email?: string; full_name?: string };
}

export default function Topbar({ user }: TopbarProps) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSignOut() {
    setLoading(true);
    await signOut();
    router.push("/auth/login");
  }

  return (
    <header
      className="flex items-center justify-between px-6 py-4 shrink-0"
      style={{
        background: "var(--surface)",
        borderBottom: "1px solid var(--border)",
        height: "64px",
      }}
    >
      {/* Left: Page title placeholder (filled by children via context or slot) */}
      <div className="text-sm font-medium" style={{ color: "var(--muted)" }}>
        AYZEN Dashboard
      </div>

      {/* Right: User menu */}
      <div className="relative">
        <button
          onClick={() => setMenuOpen((v) => !v)}
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all"
          style={{ background: "rgba(255,255,255,0.05)", color: "var(--foreground)" }}
        >
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
            style={{ background: "rgba(99,102,241,0.2)", color: "var(--primary)" }}
          >
            {(user.full_name || user.email || "U")[0].toUpperCase()}
          </div>
          <span className="hidden sm:block max-w-[120px] truncate">
            {user.full_name || user.email}
          </span>
          <span style={{ color: "var(--muted)" }}>▾</span>
        </button>

        {menuOpen && (
          <div
            className="absolute right-0 top-full mt-2 w-48 rounded-lg py-1 z-50"
            style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}
          >
            <div className="px-3 py-2 text-xs" style={{ color: "var(--muted)" }}>
              {user.email}
            </div>
            <div style={{ borderTop: "1px solid var(--border)" }} className="my-1" />
            <a
              href="/dashboard/settings"
              className="flex items-center gap-2 px-3 py-2 text-sm transition-all hover:bg-white/5"
              style={{ color: "var(--foreground)" }}
              onClick={() => setMenuOpen(false)}
            >
              ⚙️ Settings
            </a>
            <button
              onClick={handleSignOut}
              disabled={loading}
              className="flex items-center gap-2 px-3 py-2 text-sm w-full text-left transition-all hover:bg-white/5"
              style={{ color: loading ? "var(--muted)" : "#ef4444" }}
            >
              🚪 {loading ? "Signing out..." : "Sign out"}
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
