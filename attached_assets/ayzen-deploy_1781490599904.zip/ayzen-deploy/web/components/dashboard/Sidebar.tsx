// ID: AX85      |  Local: A62Y1         |  Module: X66 (M65)
// Functions: A62Y1F1 A62Y1F2 A62Y1F3
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

interface NavItem {
  href: string;
  label: string;
  icon: string;
  adminOnly?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: "📊" },
  { href: "/dashboard/projects", label: "Projects", icon: "📁" },
  { href: "/dashboard/tasks", label: "Tasks", icon: "📋" },
  { href: "/dashboard/members", label: "Members", icon: "👥" },
  { href: "/dashboard/progress", label: "Progress", icon: "📈" },
  { href: "/dashboard/analytics", label: "Analytics", icon: "🔬", adminOnly: true },
  { href: "/dashboard/broadcasts", label: "Broadcasts", icon: "📢", adminOnly: true },
  { href: "/dashboard/exports", label: "Exports", icon: "📥" },
  { href: "/dashboard/settings", label: "Settings", icon: "⚙️" },
];

interface SidebarProps {
  user: { role?: string; email?: string; full_name?: string };
}

export default function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname();
  const isAdmin = user.role === "owner" || user.role === "manager";

  return (
    <aside
      className="w-64 flex-shrink-0 flex flex-col h-full"
      style={{
        background: "var(--surface)",
        borderRight: "1px solid var(--border)",
      }}
    >
      {/* Logo */}
      <div className="p-6 border-b" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold"
            style={{ background: "var(--primary)", color: "white" }}
          >
            AZ
          </div>
          <span className="font-bold text-lg" style={{ color: "var(--foreground)" }}>
            AYZEN
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 overflow-y-auto">
        <div className="space-y-1">
          {NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin).map((item) => {
            const isActive =
              pathname === item.href ||
              (item.href !== "/dashboard" && pathname.startsWith(item.href));

            return (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all"
                style={{
                  background: isActive ? "rgba(99,102,241,0.15)" : "transparent",
                  color: isActive ? "var(--primary)" : "var(--muted)",
                  fontWeight: isActive ? 600 : 400,
                }}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* User footer */}
      <div className="p-4 border-t" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
            style={{ background: "rgba(99,102,241,0.2)", color: "var(--primary)" }}
          >
            {(user.full_name || user.email || "U")[0].toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium truncate" style={{ color: "var(--foreground)" }}>
              {user.full_name || user.email}
            </div>
            <div className="text-xs" style={{ color: "var(--muted)" }}>
              {user.role}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
