#!/usr/bin/env bash
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║       AYZEN Platform Setup           ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
echo ""

# ── 1. Check prerequisites ──────────────────────────────────────────────────
echo -e "${YELLOW}▶ Checking prerequisites...${NC}"
for cmd in docker docker-compose openssl; do
  if ! command -v $cmd &>/dev/null; then
    echo -e "${RED}✗ $cmd not found. Please install it first.${NC}"
    exit 1
  fi
done
echo -e "${GREEN}✓ All prerequisites found${NC}"

# ── 2. Create .env if missing ───────────────────────────────────────────────
if [ ! -f .env ]; then
  echo -e "${YELLOW}▶ Creating .env from template...${NC}"
  cp .env.example .env

  # Generate random secrets
  WEBHOOK_SECRET=$(openssl rand -hex 32)
  WEBHOOK_TOKEN=$(openssl rand -hex 32)
  DB_PASS=$(openssl rand -hex 16)

  sed -i "s/change_me_strong_password/$DB_PASS/" .env
  sed -i "s/generate_with__openssl_rand_hex_32/$WEBHOOK_SECRET/" .env
  # Second occurrence (INTERNAL_WEBHOOK_TOKEN)
  sed -i "0,/$WEBHOOK_SECRET/! s/$WEBHOOK_SECRET/$WEBHOOK_TOKEN/" .env

  echo -e "${GREEN}✓ .env created with generated secrets${NC}"
  echo -e "${YELLOW}⚠  Edit .env and fill in your SUPABASE_* and TELEGRAM_BOT_TOKEN values${NC}"
  echo ""
  read -p "Press Enter after editing .env to continue..." _
fi

# ── 3. Build & start ────────────────────────────────────────────────────────
echo -e "${YELLOW}▶ Building Docker images...${NC}"
docker-compose build

echo -e "${YELLOW}▶ Starting services...${NC}"
docker-compose up -d

# ── 4. Wait for API health ──────────────────────────────────────────────────
echo -e "${YELLOW}▶ Waiting for API to be ready...${NC}"
for i in $(seq 1 30); do
  if curl -sf http://localhost:8000/api/v1/health &>/dev/null; then
    echo -e "${GREEN}✓ API is healthy${NC}"
    break
  fi
  sleep 2
done

# ── 5. Register Telegram webhook ────────────────────────────────────────────
if grep -q "TELEGRAM_BOT_TOKEN=123456" .env; then
  echo -e "${YELLOW}⚠  Skipping webhook registration — TELEGRAM_BOT_TOKEN not set${NC}"
else
  source .env
  if [ -n "$NEXT_PUBLIC_API_URL" ] && [ "$NEXT_PUBLIC_API_URL" != "https://your-domain.com" ]; then
    echo -e "${YELLOW}▶ Registering Telegram webhook...${NC}"
    WEBHOOK_URL="${NEXT_PUBLIC_API_URL}/api/v1/telegram/webhook"
    curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
      -d "url=${WEBHOOK_URL}" \
      -d "secret_token=${TELEGRAM_WEBHOOK_SECRET}" | python3 -m json.tool
    echo -e "${GREEN}✓ Webhook registered${NC}"
  else
    echo -e "${YELLOW}⚠  Set NEXT_PUBLIC_API_URL in .env to register Telegram webhook${NC}"
  fi
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo -e "${GREEN}  AYZEN is running!${NC}"
echo -e "${GREEN}─────────────────────────────────────${NC}"
echo -e "  Web dashboard : http://localhost:3000"
echo -e "  API           : http://localhost:8000/api/v1/health"
echo -e "  (via nginx)   : http://localhost:80"
echo -e "${GREEN}═══════════════════════════════════════${NC}"
